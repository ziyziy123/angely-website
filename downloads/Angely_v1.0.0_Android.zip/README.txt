﻿Angely v1.0.0 - Placeholder Installer
=====================================
The full application is under development.
This file is a download placeholder.

Website: https://ziyziy123.github.io/angely-website
Platform: Android 8.0+
